import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import time

class ModelComparison:
    def __init__(self, detector):
        self.detector = detector
        self.results = {}
    
    def comprehensive_evaluation(self, X, y, cv_folds=5):
        """Perform comprehensive evaluation of all models"""
        print("COMPREHENSIVE MODEL EVALUATION")
        print("="*60)
        
        # Prepare cross-validation
        cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
        
        # Split data for final testing
        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, 
                                                           random_state=42, stratify=y)
        
        # Train all models
        self.detector.train_models(X_train, y_train)
        
        # Evaluate each model
        for name, model in self.detector.models.items():
            print(f"\nEvaluating {name}...")
            
            # Cross-validation scores
            cv_scores = cross_val_score(model, X_train, y_train, cv=cv, scoring='accuracy')
            
            # Test set predictions
            start_time = time.time()
            y_pred = model.predict(X_test)
            prediction_time = time.time() - start_time
            
            # Calculate metrics
            accuracy = accuracy_score(y_test, y_pred)
            precision = precision_score(y_test, y_pred, pos_label='spam')
            recall = recall_score(y_test, y_pred, pos_label='spam')
            f1 = f1_score(y_test, y_pred, pos_label='spam')
            
            # Store results
            self.results[name] = {
                'cv_mean': cv_scores.mean(),
                'cv_std': cv_scores.std(),
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1_score': f1,
                'prediction_time': prediction_time,
                'cv_scores': cv_scores
            }
            
            print(f"  Cross-validation: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")
            print(f"  Test Accuracy: {accuracy:.4f}")
            print(f"  Precision: {precision:.4f}")
            print(f"  Recall: {recall:.4f}")
            print(f"  F1-Score: {f1:.4f}")
            print(f"  Prediction Time: {prediction_time:.4f}s")
        
        # Create comparison visualizations
        self.plot_model_comparison()
        self.plot_cv_scores()
        
        return self.results
    
    def plot_model_comparison(self):
        """Plot comparison of model metrics"""
        if not self.results:
            print("No results to plot!")
            return
        
        # Prepare data for plotting
        models = list(self.results.keys())
        metrics = ['accuracy', 'precision', 'recall', 'f1_score']
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        axes = axes.ravel()
        
        for i, metric in enumerate(metrics):
            values = [self.results[model][metric] for model in models]
            bars = axes[i].bar(models, values, alpha=0.7)
            axes[i].set_title(f'{metric.replace("_", " ").title()} Comparison')
            axes[i].set_ylabel(metric.replace("_", " ").title())
            axes[i].set_ylim(0, 1)
            
            # Add value labels on bars
            for bar, value in zip(bars, values):
                axes[i].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                           f'{value:.3f}', ha='center', va='bottom')
            
            # Rotate x-axis labels if needed
            axes[i].tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.show()
    
    def plot_cv_scores(self):
        """Plot cross-validation scores distribution"""
        if not self.results:
            print("No results to plot!")
            return
        
        plt.figure(figsize=(12, 6))
        
        # Box plot of CV scores
        cv_data = [self.results[model]['cv_scores'] for model in self.results.keys()]
        model_names = list(self.results.keys())
        
        plt.boxplot(cv_data, labels=model_names)
        plt.title('Cross-Validation Scores Distribution')
        plt.ylabel('Accuracy Score')
        plt.xticks(rotation=45)
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
    
    def generate_report(self):
        """Generate a comprehensive report"""
        if not self.results:
            print("No results available!")
            return
        
        print("\n" + "="*80)
        print("COMPREHENSIVE MODEL EVALUATION REPORT")
        print("="*80)
        
        # Create DataFrame for easy comparison
        df_results = pd.DataFrame(self.results).T
        df_results = df_results.round(4)
        
        print("\nModel Performance Summary:")
        print("-" * 40)
        print(df_results[['accuracy', 'precision', 'recall', 'f1_score', 'cv_mean', 'cv_std']])
        
        # Find best models for each metric
        print("\nBest Models by Metric:")
        print("-" * 25)
        for metric in ['accuracy', 'precision', 'recall', 'f1_score']:
            best_model = df_results[metric].idxmax()
            best_score = df_results.loc[best_model, metric]
            print(f"  {metric.title()}: {best_model} ({best_score:.4f})")
        
        # Overall recommendation
        print("\nRecommendation:")
        print("-" * 15)
        
        # Calculate overall score (weighted average)
        df_results['overall_score'] = (
            df_results['accuracy'] * 0.3 +
            df_results['precision'] * 0.25 +
            df_results['recall'] * 0.25 +
            df_results['f1_score'] * 0.2
        )
        
        best_overall = df_results['overall_score'].idxmax()
        print(f"Best Overall Model: {best_overall}")
        print(f"Overall Score: {df_results.loc[best_overall, 'overall_score']:.4f}")
        
        # Performance vs Speed analysis
        print(f"\nFastest Model: {df_results['prediction_time'].idxmin()}")
        print(f"Prediction Time: {df_results['prediction_time'].min():.4f}s")

def run_model_comparison():
    """Run comprehensive model comparison"""
    from spam_detector import SpamDetector
    
    # Initialize detector and load data
    detector = SpamDetector()
    df = detector.load_sample_data()
    
    # Preprocess data
    df['processed_email'] = df['email'].apply(detector.preprocess_text)
    
    X = df['processed_email']
    y = df['label']
    
    # Run comparison
    comparator = ModelComparison(detector)
    results = comparator.comprehensive_evaluation(X, y)
    
    # Generate report
    comparator.generate_report()

if __name__ == "__main__":
    run_model_comparison()
