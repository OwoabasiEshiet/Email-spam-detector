import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.spam_detector import SpamDetector
from src.data_preprocessor import DataPreprocessor

def analyze_dataset():
    """Perform comprehensive data analysis"""
    print("EMAIL SPAM DATASET ANALYSIS")
    print("="*50)
    
    # Initialize components
    detector = SpamDetector()
    preprocessor = DataPreprocessor()
    
    # Load data
    df = detector.load_sample_data()
    
    # Basic statistics
    print(f"\nDataset Overview:")
    print(f"Total emails: {len(df)}")
    print(f"Spam emails: {df['label'].value_counts()['spam']}")
    print(f"Ham emails: {df['label'].value_counts()['ham']}")
    print(f"Balance ratio: {df['label'].value_counts()['spam'] / len(df):.2%} spam")
    
    # Extract features
    print("\nExtracting features...")
    for idx, row in df.iterrows():
        features = preprocessor.extract_features(row['email'])
        for key, value in features.items():
            df.at[idx, key] = value
    
    # Feature analysis
    feature_cols = ['length', 'word_count', 'exclamation_count', 'capital_ratio', 
                   'dollar_signs', 'free_count', 'urgent_count']
    
    print("\nFeature Statistics by Email Type:")
    print(df.groupby('label')[feature_cols].mean().round(3))
    
    # Visualizations
    plt.figure(figsize=(15, 10))
    
    # Feature distributions
    for i, feature in enumerate(feature_cols[:6], 1):
        plt.subplot(2, 3, i)
        for label in ['ham', 'spam']:
            data = df[df['label'] == label][feature]
            plt.hist(data, alpha=0.7, label=label, bins=10)
        plt.title(f'{feature.replace("_", " ").title()}')
        plt.legend()
    
    plt.tight_layout()
    plt.show()
    
    # Word clouds
    df['processed_email'] = df['email'].apply(preprocessor.preprocess_text)
    
    spam_text = ' '.join(df[df['label'] == 'spam']['processed_email'])
    ham_text = ' '.join(df[df['label'] == 'ham']['processed_email'])
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8))
    
    # Spam word cloud
    spam_wordcloud = WordCloud(width=400, height=400, 
                              background_color='white',
                              colormap='Reds').generate(spam_text)
    ax1.imshow(spam_wordcloud, interpolation='bilinear')
    ax1.set_title('Most Common Words in Spam Emails', fontsize=16)
    ax1.axis('off')
    
    # Ham word cloud
    ham_wordcloud = WordCloud(width=400, height=400, 
                             background_color='white',
                             colormap='Blues').generate(ham_text)
    ax2.imshow(ham_wordcloud, interpolation='bilinear')
    ax2.set_title('Most Common Words in Legitimate Emails', fontsize=16)
    ax2.axis('off')
    
    plt.tight_layout()
    plt.show()
    
    print("\nAnalysis completed!")

if __name__ == "__main__":
    analyze_dataset()
