import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import roc_curve, auc
import re

class AdvancedSpamAnalysis:
    def __init__(self, detector):
        self.detector = detector
    
    def analyze_email_features(self, df):
        """Analyze various features of emails"""
        print("ADVANCED EMAIL FEATURE ANALYSIS")
        print("="*50)
        
        # Add feature columns
        df['email_length'] = df['email'].str.len()
        df['word_count'] = df['email'].str.split().str.len()
        df['exclamation_count'] = df['email'].str.count('!')
        df['question_count'] = df['email'].str.count('\?')
        df['capital_ratio'] = df['email'].apply(lambda x: sum(1 for c in x if c.isupper()) / len(x) if len(x) > 0 else 0)
        df['dollar_count'] = df['email'].str.count('\$')
        df['url_count'] = df['email'].str.count(r'http[s]?://|www\.')
        
        # Statistical analysis
        feature_stats = df.groupby('label')[['email_length', 'word_count', 'exclamation_count', 
                                           'capital_ratio', 'dollar_count']].mean()
        
        print("\nFeature Statistics by Email Type:")
        print(feature_stats.round(3))
        
        # Visualizations
        self.plot_feature_distributions(df)
        
        return df
    
    def plot_feature_distributions(self, df):
        """Plot distributions of email features"""
        features = ['email_length', 'word_count', 'exclamation_count', 'capital_ratio']
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        axes = axes.ravel()
        
        for i, feature in enumerate(features):
            for label in ['ham', 'spam']:
                data = df[df['label'] == label][feature]
                axes[i].hist(data, alpha=0.7, label=label, bins=10)
            
            axes[i].set_title(f'Distribution of {feature.replace("_", " ").title()}')
            axes[i].set_xlabel(feature.replace("_", " ").title())
            axes[i].set_ylabel('Frequency')
            axes[i].legend()
        
        plt.tight_layout()
        plt.show()
    
    def generate_word_clouds(self, df):
        """Generate word clouds for spam and ham emails"""
        spam_text = ' '.join(df[df['label'] == 'spam']['processed_email'])
        ham_text = ' '.join(df[df['label'] == 'ham']['processed_email'])
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8))
        
        # Spam word cloud
        spam_wordcloud = WordCloud(width=400, height=400, 
                                  background_color='white',
                                  colormap='Reds').generate(spam_text)
        ax1.imshow(spam_wordcloud, interpolation='bilinear')
        ax1.set_title('Most Common Words in Spam Emails', fontsize=16)
        ax1.axis('off')
        
        # Ham word cloud
        ham_wordcloud = WordCloud(width=400, height=400, 
                                 background_color='white',
                                 colormap='Blues').generate(ham_text)
        ax2.imshow(ham_wordcloud, interpolation='bilinear')
        ax2.set_title('Most Common Words in Ham Emails', fontsize=16)
        ax2.axis('off')
        
        plt.tight_layout()
        plt.show()
    
    def plot_roc_curves(self, X_test, y_test):
        """Plot ROC curves for all models"""
        plt.figure(figsize=(10, 8))
        
        for name, model in self.detector.models.items():
            if hasattr(model, 'predict_proba'):
                y_pred_proba = model.predict_proba(X_test)[:, 1]
                fpr, tpr, _ = roc_curve(y_test, y_pred_proba, pos_label='spam')
                roc_auc = auc(fpr, tpr)
                
                plt.plot(fpr, tpr, label=f'{name} (AUC = {roc_auc:.3f})')
        
        plt.plot([0, 1], [0, 1], 'k--', label='Random Classifier')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curves for Spam Detection Models')
        plt.legend(loc="lower right")
        plt.grid(True)
        plt.show()
    
    def extract_top_features(self, n_features=20):
        """Extract top features from the best model"""
        if self.detector.best_model is None:
            print("No model trained yet!")
            return
        
        # Get feature names and coefficients
        vectorizer = self.detector.best_model.named_steps['tfidf']
        classifier = self.detector.best_model.named_steps['classifier']
        
        feature_names = vectorizer.get_feature_names_out()
        
        if hasattr(classifier, 'coef_'):
            # For linear models
            coefficients = classifier.coef_[0]
            
            # Get top spam indicators (positive coefficients)
            spam_indices = np.argsort(coefficients)[-n_features:]
            spam_features = [(feature_names[i], coefficients[i]) for i in spam_indices]
            
            # Get top ham indicators (negative coefficients)
            ham_indices = np.argsort(coefficients)[:n_features]
            ham_features = [(feature_names[i], abs(coefficients[i])) for i in ham_indices]
            
            print(f"\nTop {n_features} Spam Indicators:")
            for feature, coef in reversed(spam_features):
                print(f"  {feature}: {coef:.4f}")
            
            print(f"\nTop {n_features} Ham Indicators:")
            for feature, coef in reversed(ham_features):
                print(f"  {feature}: {coef:.4f}")
        
        elif hasattr(classifier, 'feature_importances_'):
            # For tree-based models
            importances = classifier.feature_importances_
            indices = np.argsort(importances)[-n_features:]
            
            print(f"\nTop {n_features} Most Important Features:")
            for i in reversed(indices):
                print(f"  {feature_names[i]}: {importances[i]:.4f}")

def run_advanced_analysis():
    """Run advanced analysis on the spam detection model"""
    from spam_detector import SpamDetector
    
    # Initialize detector and load data
    detector = SpamDetector()
    df = detector.load_sample_data()
    
    # Preprocess data
    df['processed_email'] = df['email'].apply(detector.preprocess_text)
    
    # Split data
    from sklearn.model_selection import train_test_split
    X = df['processed_email']
    y = df['label']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
    
    # Train models
    detector.train_models(X_train, y_train)
    detector.evaluate_models(X_test, y_test)
    
    # Run advanced analysis
    analyzer = AdvancedSpamAnalysis(detector)
    
    # Analyze email features
    df_with_features = analyzer.analyze_email_features(df)
    
    # Generate word clouds
    print("\nGenerating word clouds...")
    analyzer.generate_word_clouds(df)
    
    # Plot ROC curves
    print("\nPlotting ROC curves...")
    analyzer.plot_roc_curves(X_test, y_test)
    
    # Extract top features
    print("\nExtracting top features...")
    analyzer.extract_top_features()

if __name__ == "__main__":
    run_advanced_analysis()
