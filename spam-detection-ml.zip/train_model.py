#!/usr/bin/env python3
"""
Standalone script to train the spam detection model
"""

import os
import sys
import logging
from src.spam_detector import SpamDetector
from src.data_preprocessor import DataPreprocessor
from src.model_evaluator import ModelEvaluator
from sklearn.model_selection import train_test_split

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    """Main training function"""
    logger.info("Starting spam detection model training...")
    
    # Initialize components
    detector = SpamDetector()
    preprocessor = DataPreprocessor()
    evaluator = ModelEvaluator()
    
    try:
        # Load and preprocess data
        logger.info("Loading sample data...")
        df = detector.load_sample_data()
        
        logger.info("Preprocessing email text...")
        df['processed_email'] = df['email'].apply(preprocessor.preprocess_text)
        
        # Split data
        logger.info("Splitting data...")
        X = df['processed_email']
        y = df['label']
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y
        )
        
        logger.info(f"Training set: {len(X_train)} emails")
        logger.info(f"Test set: {len(X_test)} emails")
        
        # Train models
        detector.train_models(X_train, y_train)
        
        # Evaluate models
        model_scores = detector.evaluate_models(X_test, y_test)
        
        # Comprehensive evaluation
        logger.info("Performing comprehensive evaluation...")
        evaluator.comprehensive_evaluation(detector.models, X_test, y_test)
        
        # Generate visualizations
        logger.info("Generating evaluation plots...")
        evaluator.plot_confusion_matrices(detector.models, X_test, y_test)
        evaluator.plot_roc_curves(detector.models, X_test, y_test)
        evaluator.plot_metrics_comparison()
        
        # Generate report
        evaluator.generate_report()
        
        # Save the best model
        os.makedirs('models', exist_ok=True)
        model_path = 'models/best_model.pkl'
        if detector.save_model(model_path):
            logger.info(f"Best model saved to {model_path}")
        
        # Test with sample emails
        logger.info("\nTesting with sample emails...")
        test_emails = [
            "Congratulations! You've won a free vacation! Click here now!",
            "Hi, can we reschedule our meeting to next Tuesday?",
            "URGENT: Your account will be closed unless you verify now!",
            "Your package has been delivered successfully."
        ]
        
        for email in test_emails:
            result = detector.predict_email(email)
            if result:
                print(f"\nEmail: {email[:50]}...")
                print(f"Prediction: {result['prediction'].upper()}")
                print(f"Confidence: {result['confidence']:.4f}")
                print(f"Spam probability: {result['probabilities']['spam']:.4f}")
        
        logger.info("Training completed successfully!")
        
    except Exception as e:
        logger.error(f"Training failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
