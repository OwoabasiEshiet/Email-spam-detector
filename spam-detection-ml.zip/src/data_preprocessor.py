import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize
import string
import logging

logger = logging.getLogger(__name__)

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

class DataPreprocessor:
    def __init__(self):
        self.stemmer = PorterStemmer()
        self.stop_words = set(stopwords.words('english'))
        
        # Add custom stop words
        self.stop_words.update(['would', 'could', 'should', 'one', 'two', 'also'])
        
        # Spam-specific patterns
        self.spam_patterns = [
            r'\$\d+',  # Money amounts
            r'\b\d+%\s*off\b',  # Discount percentages
            r'\bfree\b',  # Free offers
            r'\burgent\b',  # Urgent messages
            r'\bclick\s+here\b',  # Click here phrases
            r'\bact\s+now\b',  # Act now phrases
        ]
    
    def preprocess_text(self, text):
        """Comprehensive text preprocessing"""
        if not isinstance(text, str):
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove URLs
        text = re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\$$\$$,]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', ' URL ', text)
        text = re.sub(r'www\.(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\$$\$$,]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', ' URL ', text)
        
        # Remove email addresses
        text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', ' EMAIL ', text)
        
        # Remove phone numbers
        text = re.sub(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', ' PHONE ', text)
        
        # Normalize money amounts
        text = re.sub(r'\$\d+(?:,\d{3})*(?:\.\d{2})?', ' MONEY ', text)
        
        # Normalize percentages
        text = re.sub(r'\d+%', ' PERCENT ', text)
        
        # Remove excessive punctuation
        text = re.sub(r'[!]{2,}', ' EXCLAMATION ', text)
        text = re.sub(r'[?]{2,}', ' QUESTION ', text)
        
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', ' ', text)
        
        # Remove special characters but keep spaces
        text = re.sub(r'[^a-zA-Z\s]', ' ', text)
        
        # Remove extra whitespace
        text = ' '.join(text.split())
        
        # Tokenize
        tokens = word_tokenize(text)
        
        # Remove stopwords and apply stemming
        processed_tokens = []
        for token in tokens:
            if token not in self.stop_words and len(token) > 2:
                stemmed_token = self.stemmer.stem(token)
                processed_tokens.append(stemmed_token)
        
        return ' '.join(processed_tokens)
    
    def extract_features(self, text):
        """Extract additional features from email text"""
        if not isinstance(text, str):
            return {}
        
        features = {}
        
        # Basic features
        features['length'] = len(text)
        features['word_count'] = len(text.split())
        features['char_count'] = len(text)
        
        # Punctuation features
        features['exclamation_count'] = text.count('!')
        features['question_count'] = text.count('?')
        features['capital_ratio'] = sum(1 for c in text if c.isupper()) / len(text) if len(text) > 0 else 0
        
        # Spam indicators
        features['dollar_signs'] = text.count('$')
        features['percent_signs'] = text.count('%')
        features['free_count'] = text.lower().count('free')
        features['urgent_count'] = text.lower().count('urgent')
        features['click_count'] = text.lower().count('click')
        
        # URL and contact info
        features['url_count'] = len(re.findall(r'http[s]?://|www\.', text))
        features['email_count'] = len(re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text))
        features['phone_count'] = len(re.findall(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', text))
        
        return features
    
    def batch_preprocess(self, texts):
        """Preprocess a batch of texts"""
        return [self.preprocess_text(text) for text in texts]
