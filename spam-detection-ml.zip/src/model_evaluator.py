import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_curve, auc
)
from sklearn.model_selection import cross_val_score, StratifiedKFold
import logging

logger = logging.getLogger(__name__)

class ModelEvaluator:
    def __init__(self):
        self.evaluation_results = {}
    
    def comprehensive_evaluation(self, models, X_test, y_test, cv_folds=5):
        """Perform comprehensive evaluation of models"""
        logger.info("Starting comprehensive model evaluation...")
        
        results = {}
        
        for name, model in models.items():
            logger.info(f"Evaluating {name}...")
            
            try:
                # Make predictions
                y_pred = model.predict(X_test)
                y_pred_proba = model.predict_proba(X_test)[:, 1] if hasattr(model, 'predict_proba') else None
                
                # Calculate metrics
                metrics = {
                    'accuracy': accuracy_score(y_test, y_pred),
                    'precision': precision_score(y_test, y_pred, pos_label='spam'),
                    'recall': recall_score(y_test, y_pred, pos_label='spam'),
                    'f1_score': f1_score(y_test, y_pred, pos_label='spam')
                }
                
                # Add AUC if probabilities available
                if y_pred_proba is not None:
                    fpr, tpr, _ = roc_curve(y_test, y_pred_proba, pos_label='spam')
                    metrics['auc'] = auc(fpr, tpr)
                
                results[name] = metrics
                
                logger.info(f"{name} - Accuracy: {metrics['accuracy']:.4f}, F1: {metrics['f1_score']:.4f}")
                
            except Exception as e:
                logger.error(f"Error evaluating {name}: {e}")
        
        self.evaluation_results = results
        return results
    
    def plot_confusion_matrices(self, models, X_test, y_test):
        """Plot confusion matrices for all models"""
        n_models = len(models)
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        axes = axes.ravel()
        
        for i, (name, model) in enumerate(models.items()):
            if i >= len(axes):
                break
                
            try:
                y_pred = model.predict(X_test)
                cm = confusion_matrix(y_test, y_pred, labels=['ham', 'spam'])
                
                sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                           xticklabels=['Ham', 'Spam'],
                           yticklabels=['Ham', 'Spam'],
                           ax=axes[i])
                axes[i].set_title(f'{name}\nConfusion Matrix')
                axes[i].set_ylabel('Actual')
                axes[i].set_xlabel('Predicted')
                
            except Exception as e:
                logger.error(f"Error plotting confusion matrix for {name}: {e}")
        
        # Hide unused subplots
        for i in range(len(models), len(axes)):
            axes[i].set_visible(False)
        
        plt.tight_layout()
        plt.show()
    
    def plot_roc_curves(self, models, X_test, y_test):
        """Plot ROC curves for all models"""
        plt.figure(figsize=(10, 8))
        
        for name, model in models.items():
            try:
                if hasattr(model, 'predict_proba'):
                    y_pred_proba = model.predict_proba(X_test)[:, 1]
                    fpr, tpr, _ = roc_curve(y_test, y_pred_proba, pos_label='spam')
                    roc_auc = auc(fpr, tpr)
                    
                    plt.plot(fpr, tpr, label=f'{name} (AUC = {roc_auc:.3f})')
                    
            except Exception as e:
                logger.error(f"Error plotting ROC curve for {name}: {e}")
        
        plt.plot([0, 1], [0, 1], 'k--', label='Random Classifier')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curves - Spam Detection Models')
        plt.legend(loc="lower right")
        plt.grid(True, alpha=0.3)
        plt.show()
    
    def plot_metrics_comparison(self):
        """Plot comparison of model metrics"""
        if not self.evaluation_results:
            logger.warning("No evaluation results available")
            return
        
        # Prepare data
        df_results = pd.DataFrame(self.evaluation_results).T
        
        # Plot metrics
        metrics = ['accuracy', 'precision', 'recall', 'f1_score']
        available_metrics = [m for m in metrics if m in df_results.columns]
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        axes = axes.ravel()
        
        for i, metric in enumerate(available_metrics):
            if i >= len(axes):
                break
                
            values = df_results[metric].values
            models = df_results.index.tolist()
            
            bars = axes[i].bar(models, values, alpha=0.7, color='skyblue')
            axes[i].set_title(f'{metric.replace("_", " ").title()} Comparison')
            axes[i].set_ylabel(metric.replace("_", " ").title())
            axes[i].set_ylim(0, 1)
            axes[i].tick_params(axis='x', rotation=45)
            
            # Add value labels on bars
            for bar, value in zip(bars, values):
                axes[i].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                           f'{value:.3f}', ha='center', va='bottom')
        
        # Hide unused subplots
        for i in range(len(available_metrics), len(axes)):
            axes[i].set_visible(False)
        
        plt.tight_layout()
        plt.show()
    
    def generate_report(self):
        """Generate a comprehensive evaluation report"""
        if not self.evaluation_results:
            logger.warning("No evaluation results available")
            return
        
        print("\n" + "="*80)
        print("COMPREHENSIVE MODEL EVALUATION REPORT")
        print("="*80)
        
        # Create DataFrame
        df_results = pd.DataFrame(self.evaluation_results).T
        df_results = df_results.round(4)
        
        print("\nModel Performance Summary:")
        print("-" * 40)
        print(df_results)
        
        # Find best models for each metric
        print("\nBest Models by Metric:")
        print("-" * 25)
        for metric in df_results.columns:
            best_model = df_results[metric].idxmax()
            best_score = df_results.loc[best_model, metric]
            print(f"  {metric.title()}: {best_model} ({best_score:.4f})")
        
        # Overall recommendation
        if 'f1_score' in df_results.columns:
            best_overall = df_results['f1_score'].idxmax()
            print(f"\nRecommended Model: {best_overall}")
            print(f"F1-Score: {df_results.loc[best_overall, 'f1_score']:.4f}")
        
        return df_results
