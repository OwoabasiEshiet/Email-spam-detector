import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.pipeline import Pipeline
import pickle
import logging

logger = logging.getLogger(__name__)

class SpamDetector:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            max_features=5000, 
            stop_words='english',
            ngram_range=(1, 2),
            min_df=2,
            max_df=0.95
        )
        
        self.models = {
            'Naive Bayes': MultinomialNB(alpha=0.1),
            'Logistic Regression': LogisticRegression(
                random_state=42, 
                max_iter=1000,
                C=1.0
            ),
            'SVM': SVC(
                kernel='linear', 
                random_state=42, 
                probability=True,
                C=1.0
            ),
            'Random Forest': RandomForestClassifier(
                n_estimators=100, 
                random_state=42,
                max_depth=10
            ),
            'Gradient Boosting': GradientBoostingClassifier(
                n_estimators=100,
                random_state=42,
                learning_rate=0.1
            )
        }
        
        self.best_model = None
        self.best_model_name = None
        self.training_history = []
    
    def load_sample_data(self):
        """Load comprehensive sample dataset"""
        # Extended spam emails with various patterns
        spam_emails = [
            "CONGRATULATIONS! You've won $1,000,000! Click here to claim NOW!",
            "URGENT: Your account will be suspended. Verify your details immediately.",
            "Get rich quick! Make $5000/week from home with this amazing opportunity!",
            "FREE VIAGRA! Best prices guaranteed. Order now, discreet shipping!",
            "You have inherited $5,000,000 from a distant relative. Contact us immediately.",
            "LIMITED TIME: 90% discount on luxury watches! Buy now before it's too late!",
            "Your credit card has been charged $500. If unauthorized, click here ASAP.",
            "Lose 30 pounds in 30 days with this miracle pill! No diet or exercise!",
            "APPROVED: $50,000 loan pre-approved. Apply now, no credit check required!",
            "Hot singles in your area want to meet you tonight! Join free now!",
            "WARNING: Your computer is infected with 5 viruses! Download cleaner now!",
            "Earn $10,000/month working from home! No experience needed, start today!",
            "FINAL NOTICE: You owe $2,500 in taxes. Pay now to avoid arrest!",
            "Get a FREE iPhone 15 by completing this 2-minute survey! Limited time!",
            "Your PayPal account has been limited. Click here to restore access now!",
            "BREAKING: New cryptocurrency will make you rich! Invest $100, get $10,000!",
            "You've been selected for a $25,000 government grant! Claim now!",
            "ALERT: Suspicious activity on your bank account. Verify identity now!",
            "Make money online! $500/day guaranteed with this secret method!",
            "Your subscription expires today! Renew now for 50% off! Act fast!"
        ]
        
        # Extended legitimate emails
        ham_emails = [
            "Hi John, can we schedule our weekly team meeting for Thursday at 2 PM?",
            "Your Amazon order #123456 has been shipped and will arrive tomorrow.",
            "Thank you for your purchase. Your receipt and warranty info are attached.",
            "Reminder: Your dentist appointment is scheduled for Friday at 10:30 AM.",
            "The quarterly financial report is ready for your review and approval.",
            "Happy birthday! Hope you have a wonderful celebration with family.",
            "Your Netflix subscription will renew automatically on the 15th.",
            "The conference room booking for Monday's presentation has been confirmed.",
            "Please review the attached project proposal and provide your feedback.",
            "Your flight to Chicago has been confirmed for next Tuesday at 8:45 AM.",
            "The software update has been installed successfully on all systems.",
            "Your monthly bank statement is now available in your online account.",
            "Thank you for attending today's webinar. The recording is now available.",
            "Weather update: Tomorrow's outdoor event may be affected by rain.",
            "Your library books are due for return by next Friday. Renewal available.",
            "The team lunch has been moved to the cafeteria on the second floor.",
            "Your car service appointment is confirmed for Saturday at 9 AM.",
            "Please complete the employee satisfaction survey by end of week.",
            "Your health insurance enrollment period ends on December 31st.",
            "The new employee handbook has been uploaded to the company portal."
        ]
        
        # Create balanced dataset
        emails = spam_emails + ham_emails
        labels = ['spam'] * len(spam_emails) + ['ham'] * len(ham_emails)
        
        df = pd.DataFrame({
            'email': emails,
            'label': labels
        })
        
        # Shuffle the dataset
        df = df.sample(frac=1, random_state=42).reset_index(drop=True)
        
        logger.info(f"Dataset created: {len(df)} emails ({df['label'].value_counts()['spam']} spam, {df['label'].value_counts()['ham']} ham)")
        
        return df
    
    def train_models(self, X_train, y_train):
        """Train all models with pipelines"""
        logger.info("Training models...")
        
        for name, model in self.models.items():
            try:
                # Create pipeline
                pipeline = Pipeline([
                    ('tfidf', self.vectorizer),
                    ('classifier', model)
                ])
                
                # Train the model
                pipeline.fit(X_train, y_train)
                
                # Store the trained pipeline
                self.models[name] = pipeline
                
                logger.info(f"✓ {name} trained successfully")
                
            except Exception as e:
                logger.error(f"Error training {name}: {e}")
        
        logger.info("All models trained successfully!")
    
    def evaluate_models(self, X_test, y_test):
        """Evaluate all models and select the best one"""
        model_scores = {}
        
        logger.info("Evaluating models...")
        
        for name, model in self.models.items():
            try:
                # Make predictions
                y_pred = model.predict(X_test)
                
                # Calculate accuracy
                accuracy = accuracy_score(y_test, y_pred)
                model_scores[name] = accuracy
                
                logger.info(f"{name}: {accuracy:.4f}")
                
            except Exception as e:
                logger.error(f"Error evaluating {name}: {e}")
                model_scores[name] = 0.0
        
        # Find best model
        if model_scores:
            self.best_model_name = max(model_scores, key=model_scores.get)
            self.best_model = self.models[self.best_model_name]
            
            logger.info(f"Best Model: {self.best_model_name} (Accuracy: {model_scores[self.best_model_name]:.4f})")
        
        return model_scores
    
    def predict_email(self, email_text):
        """Predict if an email is spam or ham"""
        if self.best_model is None:
            logger.warning("No model has been trained yet!")
            return None
        
        try:
            # Make prediction
            prediction = self.best_model.predict([email_text])[0]
            probabilities = self.best_model.predict_proba([email_text])[0]
            
            # Get class labels
            classes = self.best_model.classes_
            prob_dict = dict(zip(classes, probabilities))
            
            return {
                'prediction': prediction,
                'confidence': max(probabilities),
                'probabilities': prob_dict
            }
            
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return None
    
    def save_model(self, filename):
        """Save the trained model"""
        if self.best_model is None:
            logger.warning("No model to save!")
            return False
        
        try:
            model_data = {
                'model': self.best_model,
                'model_name': self.best_model_name,
                'training_history': self.training_history
            }
            
            with open(filename, 'wb') as f:
                pickle.dump(model_data, f)
            
            logger.info(f"Model saved as {filename}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving model: {e}")
            return False
    
    def load_model(self, filename):
        """Load a saved model"""
        try:
            with open(filename, 'rb') as f:
                model_data = pickle.load(f)
                
            self.best_model = model_data['model']
            self.best_model_name = model_data['model_name']
            self.training_history = model_data.get('training_history', [])
            
            logger.info(f"Model loaded: {self.best_model_name}")
            return True
            
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            return False
