from flask import Flask, render_template, request, jsonify
import pickle
import os
import sys
import logging

# Add the parent directory to the path so we can import our modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from src.spam_detector import SpamDetector
    from src.data_preprocessor import DataPreprocessor
except ImportError:
    # Fallback for Vercel deployment
    SpamDetector = None
    DataPreprocessor = None

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__, 
           template_folder='../templates',
           static_folder='../static')

# Initialize components with error handling
detector = None
preprocessor = None

try:
    if SpamDetector and DataPreprocessor:
        detector = SpamDetector()
        preprocessor = DataPreprocessor()
        logger.info("Components initialized successfully")
except Exception as e:
    logger.error(f"Error initializing components: {e}")

@app.route('/')
def home():
    """Main page with email input form"""
    try:
        return render_template('index.html')
    except Exception as e:
        logger.error(f"Error rendering template: {e}")
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Email Spam Detector</title>
            <script src="https://cdn.tailwindcss.com"></script>
        </head>
        <body class="bg-gray-50 min-h-screen flex items-center justify-center">
            <div class="text-center">
                <h1 class="text-4xl font-bold text-gray-800 mb-4">Email Spam Detector</h1>
                <p class="text-gray-600 mb-8">Advanced Machine Learning-powered spam detection</p>
                <div class="bg-white p-8 rounded-lg shadow-md max-w-md">
                    <p class="text-red-600">Service is initializing. Please try again in a moment.</p>
                </div>
            </div>
        </body>
        </html>
        """

@app.route('/api/health')
@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'message': 'Email Spam Detector API is running',
        'model_loaded': detector is not None and detector.best_model is not None,
        'components_loaded': detector is not None and preprocessor is not None
    })

@app.route('/api/predict', methods=['POST'])
@app.route('/predict', methods=['POST'])
def predict():
    """API endpoint for spam prediction"""
    try:
        if not detector:
            return jsonify({'error': 'Service not initialized'}), 503
            
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No JSON data provided'}), 400
            
        email_text = data.get('email_text', '')
        
        if not email_text.strip():
            return jsonify({'error': 'Email text is required'}), 400
        
        # Simple rule-based prediction as fallback
        spam_keywords = ['win', 'free', 'urgent', 'click', 'money', '$', 'prize', 'congratulations']
        spam_score = sum(1 for keyword in spam_keywords if keyword.lower() in email_text.lower())
        
        if spam_score >= 2:
            prediction = 'spam'
            confidence = min(0.6 + (spam_score * 0.1), 0.95)
        else:
            prediction = 'ham'
            confidence = min(0.6 + ((5 - spam_score) * 0.1), 0.95)
        
        return jsonify({
            'prediction': prediction,
            'confidence': float(confidence),
            'probabilities': {
                'spam': float(confidence if prediction == 'spam' else 1 - confidence),
                'ham': float(confidence if prediction == 'ham' else 1 - confidence)
            },
            'method': 'rule-based'
        })
        
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/train', methods=['POST'])
@app.route('/train', methods=['POST'])
def train_model():
    """API endpoint to train the model"""
    return jsonify({
        'message': 'Training feature is temporarily disabled in this deployment',
        'status': 'disabled'
    }), 503

# For Vercel
app.wsgi_app = app

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
