from flask import Flask, render_template, request, jsonify
import pickle
import os
from src.spam_detector import SpamDetector
from src.data_preprocessor import DataPreprocessor
import logging
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Initialize components
detector = SpamDetector()
preprocessor = DataPreprocessor()

# Load trained model if available
MODEL_PATH = 'models/best_model.pkl'
if os.path.exists(MODEL_PATH):
    try:
        detector.load_model(MODEL_PATH)
        logger.info("Model loaded successfully")
    except Exception as e:
        logger.error(f"Error loading model: {e}")

@app.route('/')
def home():
    """Main page with email input form"""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    """API endpoint for spam prediction"""
    try:
        data = request.get_json()
        email_text = data.get('email_text', '')
        
        if not email_text.strip():
            return jsonify({'error': 'Email text is required'}), 400
        
        # Make prediction
        result = detector.predict_email(email_text)
        
        if result is None:
            return jsonify({'error': 'Model not trained. Please train the model first.'}), 400
        
        return jsonify({
            'prediction': result['prediction'],
            'confidence': float(result['confidence']),
            'probabilities': {
                'spam': float(result['probabilities']['spam']),
                'ham': float(result['probabilities']['ham'])
            }
        })
        
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/train', methods=['POST'])
def train_model():
    """API endpoint to train the model"""
    try:
        logger.info("Starting model training...")
        
        # Load and preprocess data
        df = detector.load_sample_data()
        df['processed_email'] = df['email'].apply(preprocessor.preprocess_text)
        
        # Split data
        from sklearn.model_selection import train_test_split
        X = df['processed_email']
        y = df['label']
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y
        )
        
        # Train models
        detector.train_models(X_train, y_train)
        scores = detector.evaluate_models(X_test, y_test)
        
        # Save the best model
        os.makedirs('models', exist_ok=True)
        detector.save_model(MODEL_PATH)
        
        logger.info("Model training completed successfully")
        
        return jsonify({
            'message': 'Model trained successfully',
            'best_model': detector.best_model_name,
            'scores': scores
        })
        
    except Exception as e:
        logger.error(f"Training error: {e}")
        return jsonify({'error': 'Training failed'}), 500

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'model_loaded': detector.best_model is not None,
        'model_name': detector.best_model_name if detector.best_model else None
    })

# Configure for Vercel
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

# For Vercel, we need to expose the app
if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
else:
    # This is for Vercel
    application = app
