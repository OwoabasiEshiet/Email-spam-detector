import pandas as pd
import numpy as np
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.pipeline import Pipeline
import pickle
import matplotlib.pyplot as plt
import seaborn as sns

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

class SpamDetector:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(max_features=5000, stop_words='english')
        self.models = {
            'Naive Bayes': MultinomialNB(),
            'Logistic Regression': LogisticRegression(random_state=42),
            'SVM': SVC(kernel='linear', random_state=42),
            'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42)
        }
        self.best_model = None
        self.best_model_name = None
        self.stemmer = PorterStemmer()
        self.stop_words = set(stopwords.words('english'))
    
    def preprocess_text(self, text):
        """Clean and preprocess email text"""
        # Convert to lowercase
        text = text.lower()
        
        # Remove special characters and digits
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Remove extra whitespace
        text = ' '.join(text.split())
        
        # Remove stopwords and apply stemming
        words = text.split()
        words = [self.stemmer.stem(word) for word in words if word not in self.stop_words]
        
        return ' '.join(words)
    
    def load_sample_data(self):
        """Create sample spam/ham email data for demonstration"""
        # Sample spam emails
        spam_emails = [
            "Congratulations! You've won $1000000! Click here to claim your prize now!",
            "URGENT: Your account will be suspended. Verify your details immediately.",
            "Get rich quick! Make money from home with this amazing opportunity!",
            "Free viagra! Best prices guaranteed. Order now!",
            "You have inherited $5000000 from a distant relative. Contact us immediately.",
            "Limited time offer! Buy now and get 90% discount!",
            "Your credit card has been charged $500. If this wasn't you, click here.",
            "Lose weight fast with this miracle pill! No exercise needed!",
            "You've been selected for a special loan offer. Apply now!",
            "Hot singles in your area want to meet you tonight!",
            "Your computer is infected! Download our antivirus now!",
            "Earn $5000 per week working from home! No experience required!",
            "Your PayPal account has been limited. Verify now to restore access.",
            "Get a free iPhone by completing this survey!",
            "You owe $1000 in taxes. Pay immediately to avoid legal action."
        ]
        
        # Sample legitimate emails
        ham_emails = [
            "Hi John, can we schedule a meeting for tomorrow at 2 PM?",
            "Your order has been shipped and will arrive in 2-3 business days.",
            "Thank you for your purchase. Your receipt is attached.",
            "Reminder: Your appointment is scheduled for Friday at 10 AM.",
            "The quarterly report is ready for your review.",
            "Happy birthday! Hope you have a wonderful day.",
            "Your subscription renewal is due next month.",
            "The team meeting has been moved to conference room B.",
            "Please find the updated project timeline attached.",
            "Your flight booking confirmation for next week's trip.",
            "The software update has been successfully installed.",
            "Your monthly statement is now available online.",
            "Thank you for attending today's presentation.",
            "The weather forecast shows rain for tomorrow's event.",
            "Your library books are due for return next Tuesday."
        ]
        
        # Create DataFrame
        emails = spam_emails + ham_emails
        labels = ['spam'] * len(spam_emails) + ['ham'] * len(ham_emails)
        
        df = pd.DataFrame({
            'email': emails,
            'label': labels
        })
        
        return df
    
    def train_models(self, X_train, y_train):
        """Train multiple models and find the best one"""
        model_scores = {}
        
        print("Training models...")
        for name, model in self.models.items():
            # Create pipeline with vectorizer and model
            pipeline = Pipeline([
                ('tfidf', self.vectorizer),
                ('classifier', model)
            ])
            
            # Train the model
            pipeline.fit(X_train, y_train)
            
            # Store the trained pipeline
            self.models[name] = pipeline
            
            print(f"✓ {name} trained successfully")
        
        print("All models trained!")
    
    def evaluate_models(self, X_test, y_test):
        """Evaluate all models and select the best one"""
        model_scores = {}
        
        print("\nEvaluating models...")
        print("-" * 50)
        
        for name, model in self.models.items():
            # Make predictions
            y_pred = model.predict(X_test)
            
            # Calculate accuracy
            accuracy = accuracy_score(y_test, y_pred)
            model_scores[name] = accuracy
            
            print(f"{name}: {accuracy:.4f}")
        
        # Find best model
        self.best_model_name = max(model_scores, key=model_scores.get)
        self.best_model = self.models[self.best_model_name]
        
        print(f"\nBest Model: {self.best_model_name} (Accuracy: {model_scores[self.best_model_name]:.4f})")
        
        return model_scores
    
    def detailed_evaluation(self, X_test, y_test):
        """Provide detailed evaluation of the best model"""
        if self.best_model is None:
            print("No model has been trained yet!")
            return
        
        y_pred = self.best_model.predict(X_test)
        
        print(f"\nDetailed Evaluation - {self.best_model_name}")
        print("=" * 50)
        print("\nClassification Report:")
        print(classification_report(y_test, y_pred))
        
        # Confusion Matrix
        cm = confusion_matrix(y_test, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=['Ham', 'Spam'], yticklabels=['Ham', 'Spam'])
        plt.title(f'Confusion Matrix - {self.best_model_name}')
        plt.ylabel('Actual')
        plt.xlabel('Predicted')
        plt.show()
    
    def predict_email(self, email_text):
        """Predict if an email is spam or ham"""
        if self.best_model is None:
            print("No model has been trained yet!")
            return None
        
        # Preprocess the email
        processed_email = self.preprocess_text(email_text)
        
        # Make prediction
        prediction = self.best_model.predict([processed_email])[0]
        probability = self.best_model.predict_proba([processed_email])[0]
        
        return {
            'prediction': prediction,
            'confidence': max(probability),
            'probabilities': {
                'ham': probability[0] if self.best_model.classes_[0] == 'ham' else probability[1],
                'spam': probability[1] if self.best_model.classes_[1] == 'spam' else probability[0]
            }
        }
    
    def save_model(self, filename='spam_detector_model.pkl'):
        """Save the trained model"""
        if self.best_model is None:
            print("No model has been trained yet!")
            return
        
        with open(filename, 'wb') as f:
            pickle.dump({
                'model': self.best_model,
                'model_name': self.best_model_name
            }, f)
        
        print(f"Model saved as {filename}")
    
    def load_model(self, filename='spam_detector_model.pkl'):
        """Load a saved model"""
        try:
            with open(filename, 'rb') as f:
                saved_data = pickle.load(f)
                self.best_model = saved_data['model']
                self.best_model_name = saved_data['model_name']
            
            print(f"Model loaded: {self.best_model_name}")
        except FileNotFoundError:
            print(f"Model file {filename} not found!")

def main():
    # Initialize spam detector
    detector = SpamDetector()
    
    # Load sample data
    print("Loading sample data...")
    df = detector.load_sample_data()
    print(f"Dataset loaded: {len(df)} emails ({df['label'].value_counts()['spam']} spam, {df['label'].value_counts()['ham']} ham)")
    
    # Preprocess emails
    print("\nPreprocessing emails...")
    df['processed_email'] = df['email'].apply(detector.preprocess_text)
    
    # Split data
    X = df['processed_email']
    y = df['label']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
    
    print(f"Training set: {len(X_train)} emails")
    print(f"Test set: {len(X_test)} emails")
    
    # Train models
    detector.train_models(X_train, y_train)
    
    # Evaluate models
    model_scores = detector.evaluate_models(X_test, y_test)
    
    # Detailed evaluation
    detector.detailed_evaluation(X_test, y_test)
    
    # Test with sample emails
    print("\n" + "="*60)
    print("TESTING WITH SAMPLE EMAILS")
    print("="*60)
    
    test_emails = [
        "Congratulations! You've won a free vacation! Click here now!",
        "Hi, can we reschedule our meeting to next Tuesday?",
        "URGENT: Your account will be closed unless you verify now!",
        "Your package has been delivered successfully."
    ]
    
    for email in test_emails:
        result = detector.predict_email(email)
        print(f"\nEmail: {email[:50]}...")
        print(f"Prediction: {result['prediction'].upper()}")
        print(f"Confidence: {result['confidence']:.4f}")
        print(f"Spam probability: {result['probabilities']['spam']:.4f}")
    
    # Save the model
    detector.save_model()
    
    print("\n" + "="*60)
    print("SPAM DETECTION MODEL TRAINING COMPLETE!")
    print("="*60)

if __name__ == "__main__":
    main()
