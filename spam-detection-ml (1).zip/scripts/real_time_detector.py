import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
from spam_detector import SpamDetector

class SpamDetectorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Email Spam Detector")
        self.root.geometry("800x600")
        
        # Initialize detector
        self.detector = SpamDetector()
        self.model_trained = False
        
        self.setup_ui()
        
    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Title
        title_label = ttk.Label(main_frame, text="Email Spam Detector", 
                               font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # Train model button
        self.train_button = ttk.Button(main_frame, text="Train Model", 
                                      command=self.train_model_async)
        self.train_button.grid(row=1, column=0, sticky=tk.W, pady=(0, 10))
        
        # Status label
        self.status_label = ttk.Label(main_frame, text="Model not trained", 
                                     foreground="red")
        self.status_label.grid(row=1, column=1, sticky=tk.W, padx=(20, 0), pady=(0, 10))
        
        # Email input
        ttk.Label(main_frame, text="Enter email text:").grid(row=2, column=0, 
                                                             sticky=tk.W, pady=(10, 5))
        
        self.email_text = scrolledtext.ScrolledText(main_frame, height=10, width=70)
        self.email_text.grid(row=3, column=0, columnspan=2, pady=(0, 10), sticky=(tk.W, tk.E))
        
        # Analyze button
        self.analyze_button = ttk.Button(main_frame, text="Analyze Email", 
                                        command=self.analyze_email, state="disabled")
        self.analyze_button.grid(row=4, column=0, sticky=tk.W, pady=(0, 10))
        
        # Clear button
        clear_button = ttk.Button(main_frame, text="Clear", 
                                 command=self.clear_text)
        clear_button.grid(row=4, column=1, sticky=tk.W, padx=(20, 0), pady=(0, 10))
        
        # Results frame
        results_frame = ttk.LabelFrame(main_frame, text="Analysis Results", padding="10")
        results_frame.grid(row=5, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(10, 0))
        
        # Result labels
        self.result_label = ttk.Label(results_frame, text="", font=("Arial", 12, "bold"))
        self.result_label.grid(row=0, column=0, sticky=tk.W)
        
        self.confidence_label = ttk.Label(results_frame, text="")
        self.confidence_label.grid(row=1, column=0, sticky=tk.W, pady=(5, 0))
        
        self.probabilities_label = ttk.Label(results_frame, text="")
        self.probabilities_label.grid(row=2, column=0, sticky=tk.W, pady=(5, 0))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(3, weight=1)
        
        # Sample emails for testing
        self.add_sample_buttons(main_frame)
    
    def add_sample_buttons(self, parent):
        """Add buttons for sample emails"""
        sample_frame = ttk.LabelFrame(parent, text="Sample Emails", padding="10")
        sample_frame.grid(row=6, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(10, 0))
        
        spam_button = ttk.Button(sample_frame, text="Load Spam Sample", 
                                command=self.load_spam_sample)
        spam_button.grid(row=0, column=0, padx=(0, 10))
        
        ham_button = ttk.Button(sample_frame, text="Load Ham Sample", 
                               command=self.load_ham_sample)
        ham_button.grid(row=0, column=1)
    
    def load_spam_sample(self):
        """Load a sample spam email"""
        spam_sample = """CONGRATULATIONS! You've been selected as our WINNER!
        
You have WON $1,000,000 in our international lottery!
To claim your prize, you must act NOW!

Click here immediately: www.fake-lottery-winner.com
Or call: 1-800-SCAM-NOW

This offer expires in 24 hours! Don't miss out on your fortune!

URGENT: Send us your bank details and social security number to process your winnings!

Best regards,
International Lottery Commission"""
        
        self.email_text.delete(1.0, tk.END)
        self.email_text.insert(1.0, spam_sample)
    
    def load_ham_sample(self):
        """Load a sample legitimate email"""
        ham_sample = """Hi John,

I hope this email finds you well. I wanted to follow up on our meeting yesterday regarding the quarterly project review.

As discussed, I've attached the updated timeline and budget projections for your review. Please let me know if you have any questions or concerns.

The next team meeting is scheduled for Friday at 2 PM in Conference Room B. We'll be discussing the implementation strategy and assigning tasks for the upcoming sprint.

Looking forward to hearing your feedback.

Best regards,
Sarah Johnson
Project Manager
ABC Company"""
        
        self.email_text.delete(1.0, tk.END)
        self.email_text.insert(1.0, ham_sample)
    
    def train_model_async(self):
        """Train model in a separate thread"""
        self.train_button.config(state="disabled", text="Training...")
        self.status_label.config(text="Training model...", foreground="orange")
        
        def train_worker():
            try:
                # Load and prepare data
                df = self.detector.load_sample_data()
                df['processed_email'] = df['email'].apply(self.detector.preprocess_text)
                
                # Split data
                from sklearn.model_selection import train_test_split
                X = df['processed_email']
                y = df['label']
                X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, 
                                                                   random_state=42, stratify=y)
                
                # Train models
                self.detector.train_models(X_train, y_train)
                self.detector.evaluate_models(X_test, y_test)
                
                # Update UI in main thread
                self.root.after(0, self.training_complete)
                
            except Exception as e:
                self.root.after(0, lambda: self.training_error(str(e)))
        
        thread = threading.Thread(target=train_worker)
        thread.daemon = True
        thread.start()
    
    def training_complete(self):
        """Called when training is complete"""
        self.model_trained = True
        self.train_button.config(state="normal", text="Retrain Model")
        self.analyze_button.config(state="normal")
        self.status_label.config(text=f"Model trained: {self.detector.best_model_name}", 
                                foreground="green")
        messagebox.showinfo("Training Complete", 
                           f"Model training completed!\nBest model: {self.detector.best_model_name}")
    
    def training_error(self, error_msg):
        """Called when training fails"""
        self.train_button.config(state="normal", text="Train Model")
        self.status_label.config(text="Training failed", foreground="red")
        messagebox.showerror("Training Error", f"Model training failed:\n{error_msg}")
    
    def analyze_email(self):
        """Analyze the email text"""
        if not self.model_trained:
            messagebox.showwarning("Model Not Trained", "Please train the model first!")
            return
        
        email_content = self.email_text.get(1.0, tk.END).strip()
        if not email_content:
            messagebox.showwarning("Empty Email", "Please enter some email text to analyze!")
            return
        
        try:
            result = self.detector.predict_email(email_content)
            
            # Update result labels
            prediction = result['prediction'].upper()
            color = "red" if prediction == "SPAM" else "green"
            
            self.result_label.config(text=f"Prediction: {prediction}", foreground=color)
            self.confidence_label.config(text=f"Confidence: {result['confidence']:.2%}")
            self.probabilities_label.config(
                text=f"Spam: {result['probabilities']['spam']:.2%} | "
                     f"Ham: {result['probabilities']['ham']:.2%}"
            )
            
        except Exception as e:
            messagebox.showerror("Analysis Error", f"Error analyzing email:\n{str(e)}")
    
    def clear_text(self):
        """Clear the email text"""
        self.email_text.delete(1.0, tk.END)
        self.result_label.config(text="")
        self.confidence_label.config(text="")
        self.probabilities_label.config(text="")

def run_gui():
    """Run the GUI application"""
    root = tk.Tk()
    app = SpamDetectorGUI(root)
    root.mainloop()

if __name__ == "__main__":
    run_gui()
